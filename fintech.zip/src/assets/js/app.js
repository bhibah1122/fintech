// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize the application
    initApp();
});

// Main initialization function
function initApp() {
    // Initialize navigation
    initNavigation();
    
    // Initialize charts
    initCharts();
    
    // Initialize modals
    initModals();
    
    // Initialize forms
    initForms();
    
    // Load user data from local storage or use default data
    loadUserData();
    
    // For demo purposes, show login modal by default
    // Comment this out to bypass login screen
    // showModal('login-modal');
}

// Navigation functionality
function initNavigation() {
    const navLinks = document.querySelectorAll('.nav-links li');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            // Remove active class from all links
            navLinks.forEach(item => item.classList.remove('active'));
            
            // Add active class to clicked link
            this.classList.add('active');
            
            // Get the page to show
            const pageId = this.getAttribute('data-page') + '-page';
            
            // Hide all pages
            document.querySelectorAll('.page').forEach(page => {
                page.classList.remove('active');
            });
            
            // Show the selected page
            document.getElementById(pageId).classList.add('active');
        });
    });
}

// Initialize Chart.js charts
function initCharts() {
    // Portfolio performance chart
    const portfolioCtx = document.getElementById('portfolio-chart');
    if (portfolioCtx) {
        new Chart(portfolioCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug'],
                datasets: [{
                    label: 'Portfolio Value',
                    data: [20000, 20400, 21000, 20800, 21500, 22300, 23100, 24500],
                    borderColor: '#6200ee',
                    backgroundColor: 'rgba(98, 0, 238, 0.1)',
                    borderWidth: 2,
                    tension: 0.3,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: false,
                        grid: {
                            display: true,
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }
    
    // Asset allocation chart
    const allocationCtx = document.getElementById('allocation-chart');
    if (allocationCtx) {
        new Chart(allocationCtx, {
            type: 'doughnut',
            data: {
                labels: ['Stocks', 'Bonds', 'Real Estate', 'Crypto', 'Cash'],
                datasets: [{
                    data: [45, 25, 15, 10, 5],
                    backgroundColor: [
                        '#4CAF50',
                        '#2196F3',
                        '#FFC107',
                        '#9C27B0',
                        '#607D8B'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                },
                cutout: '70%'
            }
        });
    }
    
    // Savings history chart
    const savingsHistoryCtx = document.getElementById('savings-history-chart');
    if (savingsHistoryCtx) {
        new Chart(savingsHistoryCtx, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug'],
                datasets: [{
                    label: 'Monthly Savings',
                    data: [800, 950, 700, 1000, 1200, 850, 900, 1100],
                    backgroundColor: 'rgba(98, 0, 238, 0.7)'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            display: true,
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }
    
    // Portfolio allocation chart
    const portfolioAllocationCtx = document.getElementById('portfolio-allocation-chart');
    if (portfolioAllocationCtx) {
        new Chart(portfolioAllocationCtx, {
            type: 'pie',
            data: {
                labels: ['Stocks', 'Bonds', 'Real Estate', 'Crypto', 'Cash'],
                datasets: [{
                    data: [45, 25, 15, 10, 5],
                    backgroundColor: [
                        '#4CAF50',
                        '#2196F3',
                        '#FFC107',
                        '#9C27B0',
                        '#607D8B'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }
}

// Modal functionality
function initModals() {
    // Get all modal triggers
    const modalTriggers = {
        'add-savings-btn': 'add-savings-modal',
        'add-investment-btn': 'add-investment-modal',
        'add-goal-btn': 'add-goal-modal',
        'new-savings-account-btn': 'add-savings-modal'
    };
    
    // Add event listeners to all modal triggers
    for (const triggerId in modalTriggers) {
        const trigger = document.getElementById(triggerId);
        const modalId = modalTriggers[triggerId];
        
        if (trigger) {
            trigger.addEventListener('click', function() {
                showModal(modalId);
            });
        }
    }
    
    // Close modal functionality
    const closeButtons = document.querySelectorAll('.close-modal, .cancel-btn');
    closeButtons.forEach(button => {
        button.addEventListener('click', function() {
            const modal = this.closest('.modal');
            if (modal) {
                hideModal(modal.id);
            }
        });
    });
    
    // Auth tabs functionality
    const authTabs = document.querySelectorAll('.auth-tab');
    authTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Remove active class from all tabs
            authTabs.forEach(item => item.classList.remove('active'));
            
            // Add active class to clicked tab
            this.classList.add('active');
            
            // Hide all auth content
            document.querySelectorAll('.auth-content').forEach(content => {
                content.classList.add('hidden');
            });
            
            // Show the selected content
            const contentId = this.getAttribute('data-tab') + '-content';
            document.getElementById(contentId).classList.remove('hidden');
        });
    });
}

// Show a modal by ID
function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
    }
}

// Hide a modal by ID
function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
    }
}

// Initialize form submissions
function initForms() {
    // Login form submission
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const email = document.getElementById('login-email').value;
            const password = document.getElementById('login-password').value;
            
            // Simple validation
            if (email && password) {
                // In a real app, you would authenticate with a server
                // For demo, just close the modal and set user as logged in
                hideModal('login-modal');
                
                // Save user data to local storage
                const userData = {
                    name: 'John Doe',
                    email: email,
                    isLoggedIn: true
                };
                
                localStorage.setItem('userData', JSON.stringify(userData));
            }
        });
    }
    
    // Register form submission
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const name = document.getElementById('register-name').value;
            const email = document.getElementById('register-email').value;
            const password = document.getElementById('register-password').value;
            const confirmPassword = document.getElementById('register-confirm').value;
            const termsAccepted = document.getElementById('terms').checked;
            
            // Simple validation
            if (name && email && password && confirmPassword && termsAccepted) {
                if (password !== confirmPassword) {
                    alert('Passwords do not match');
                    return;
                }
                
                // In a real app, you would register with a server
                // For demo, just close the modal and set user as logged in
                hideModal('login-modal');
                
                // Save user data to local storage
                const userData = {
                    name: name,
                    email: email,
                    isLoggedIn: true
                };
                
                localStorage.setItem('userData', JSON.stringify(userData));
            }
        });
    }
    
    // Add savings form submission
    const addSavingsForm = document.getElementById('add-savings-form');
    if (addSavingsForm) {
        addSavingsForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const account = document.getElementById('savings-account').value;
            const amount = document.getElementById('savings-amount').value;
            const date = document.getElementById('savings-date').value;
            const notes = document.getElementById('savings-notes').value;
            
            // Simple validation
            if (account && amount && date) {
                // In a real app, you would save this to a database
                // For demo, just close the modal
                hideModal('add-savings-modal');
                
                // Add to savings data in local storage
                addSavingsTransaction(account, parseFloat(amount), date, notes);
                
                // Reset form
                this.reset();
                
                // Update UI
                updateSavingsUI();
            }
        });
    }
    
    // Add investment form submission
    const addInvestmentForm = document.getElementById('add-investment-form');
    if (addInvestmentForm) {
        addInvestmentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const type = document.getElementById('investment-type').value;
            const symbol = document.getElementById('investment-symbol').value;
            const quantity = document.getElementById('investment-quantity').value;
            const price = document.getElementById('investment-price').value;
            const date = document.getElementById('investment-date').value;
            const notes = document.getElementById('investment-notes').value;
            
            // Simple validation
            if (type && symbol && quantity && price && date) {
                // In a real app, you would save this to a database
                // For demo, just close the modal
                hideModal('add-investment-modal');
                
                // Add to investment data in local storage
                addInvestmentTransaction(type, symbol, parseFloat(quantity), parseFloat(price), date, notes);
                
                // Reset form
                this.reset();
                
                // Update UI
                updateInvestmentsUI();
            }
        });
    }
    
    // Add goal form submission
    const addGoalForm = document.getElementById('add-goal-form');
    if (addGoalForm) {
        addGoalForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const name = document.getElementById('goal-name').value;
            const amount = document.getElementById('goal-amount').value;
            const date = document.getElementById('goal-date').value;
            const initial = document.getElementById('goal-initial').value || 0;
            const monthly = document.getElementById('goal-monthly').value;
            const notes = document.getElementById('goal-notes').value;
            
            // Simple validation
            if (name && amount && date && monthly) {
                // In a real app, you would save this to a database
                // For demo, just close the modal
                hideModal('add-goal-modal');
                
                // Add to goals data in local storage
                addFinancialGoal(name, parseFloat(amount), date, parseFloat(initial), parseFloat(monthly), notes);
                
                // Reset form
                this.reset();
                
                // Update UI
                updateGoalsUI();
            }
        });
    }
    
    // Profile form submission
    const profileForm = document.querySelector('.profile-form');
    if (profileForm) {
        profileForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const name = document.getElementById('fullname').value;
            const email = document.getElementById('email').value;
            const phone = document.getElementById('phone').value;
            const dob = document.getElementById('dob').value;
            const address = document.getElementById('address').value;
            
            // Simple validation
            if (name && email) {
                // In a real app, you would save this to a database
                // For demo, just show a success message
                alert('Profile updated successfully!');
                
                // Update user data in local storage
                const userData = JSON.parse(localStorage.getItem('userData') || '{}');
                userData.name = name;
                userData.email = email;
                userData.phone = phone;
                userData.dob = dob;
                userData.address = address;
                
                localStorage.setItem('userData', JSON.stringify(userData));
            }
        });
    }
}

// Load user data from local storage
function loadUserData() {
    const userData = JSON.parse(localStorage.getItem('userData') || '{}');
    
    // Check if user is logged in
    if (userData.isLoggedIn) {
        // Update UI with user data
        updateUserUI(userData);
    } else {
        // Show login modal
        // showModal('login-modal');
    }
    
    // Load savings data
    loadSavingsData();
    
    // Load investment data
    loadInvestmentData();
    
    // Load goals data
    loadGoalsData();
}

// Update UI with user data
function updateUserUI(userData) {
    // Update user name
    const userNameElements = document.querySelectorAll('.user span');
    userNameElements.forEach(element => {
        element.textContent = userData.name || 'User';
    });
    
    // Update profile page
    const fullnameInput = document.getElementById('fullname');
    const emailInput = document.getElementById('email');
    const phoneInput = document.getElementById('phone');
    const dobInput = document.getElementById('dob');
    const addressInput = document.getElementById('address');
    
    if (fullnameInput) fullnameInput.value = userData.name || '';
    if (emailInput) emailInput.value = userData.email || '';
    if (phoneInput) phoneInput.value = userData.phone || '';
    if (dobInput) dobInput.value = userData.dob || '';
    if (addressInput) addressInput.value = userData.address || '';
}

// Savings data functions
function loadSavingsData() {
    const savingsData = JSON.parse(localStorage.getItem('savingsData') || '{}');
    
    // If no savings data exists, initialize with default data
    if (!savingsData.accounts) {
        savingsData.accounts = {
            emergency: {
                name: 'Emergency Fund',
                balance: 5000,
                apy: 1.5,
                type: 'Savings Account'
            },
            vacation: {
                name: 'Vacation Fund',
                balance: 3500,
                apy: 2.0,
                type: 'High-Yield Savings'
            },
            home: {
                name: 'Home Down Payment',
                balance: 3800,
                apy: 2.5,
                type: 'Certificate of Deposit'
            }
        };
        
        savingsData.transactions = [
            {
                account: 'emergency',
                amount: 500,
                date: '2025-08-18',
                type: 'deposit',
                notes: 'Monthly contribution'
            },
            {
                account: 'vacation',
                amount: 300,
                date: '2025-08-15',
                type: 'deposit',
                notes: 'Extra savings'
            },
            {
                account: 'home',
                amount: 1000,
                date: '2025-08-10',
                type: 'deposit',
                notes: 'Bonus allocation'
            }
        ];
        
        localStorage.setItem('savingsData', JSON.stringify(savingsData));
    }
    
    // Update UI with savings data
    updateSavingsUI();
}

function updateSavingsUI() {
    const savingsData = JSON.parse(localStorage.getItem('savingsData') || '{}');
    
    // Update total savings amount
    const totalSavings = calculateTotalSavings(savingsData);
    const savingsAmountElements = document.querySelectorAll('.savings .amount');
    savingsAmountElements.forEach(element => {
        element.textContent = formatCurrency(totalSavings);
    });
    
    // Update savings accounts list
    const accountsList = document.querySelector('.accounts-list');
    if (accountsList && savingsData.accounts) {
        accountsList.innerHTML = '';
        
        for (const accountId in savingsData.accounts) {
            const account = savingsData.accounts[accountId];
            
            const accountCard = document.createElement('div');
            accountCard.className = 'account-card';
            accountCard.innerHTML = `
                <div class="account-info">
                    <h4>${account.name}</h4>
                    <p class="account-balance">${formatCurrency(account.balance)}</p>
                    <p class="account-details">${account.type} - ${account.apy}% APY</p>
                </div>
                <div class="account-actions">
                    <button class="action-btn deposit-btn" data-account="${accountId}">Deposit</button>
                    <button class="action-btn withdraw-btn" data-account="${accountId}">Withdraw</button>
                </div>
            `;
            
            accountsList.appendChild(accountCard);
        }
        
        // Add event listeners to deposit and withdraw buttons
        const depositButtons = document.querySelectorAll('.deposit-btn');
        depositButtons.forEach(button => {
            button.addEventListener('click', function() {
                const accountId = this.getAttribute('data-account');
                document.getElementById('savings-account').value = accountId;
                showModal('add-savings-modal');
            });
        });
        
        const withdrawButtons = document.querySelectorAll('.withdraw-btn');
        withdrawButtons.forEach(button => {
            button.addEventListener('click', function() {
                const accountId = this.getAttribute('data-account');
                document.getElementById('savings-account').value = accountId;
                // Set a negative amount for withdrawal
                document.getElementById('savings-amount').setAttribute('placeholder', 'Enter withdrawal amount');
                showModal('add-savings-modal');
            });
        });
    }
}

function calculateTotalSavings(savingsData) {
    let total = 0;
    
    if (savingsData.accounts) {
        for (const accountId in savingsData.accounts) {
            total += savingsData.accounts[accountId].balance;
        }
    }
    
    return total;
}

function addSavingsTransaction(accountId, amount, date, notes) {
    const savingsData = JSON.parse(localStorage.getItem('savingsData') || '{}');
    
    // Add transaction to transactions array
    if (!savingsData.transactions) {
        savingsData.transactions = [];
    }
    
    savingsData.transactions.push({
        account: accountId,
        amount: amount,
        date: date,
        type: amount >= 0 ? 'deposit' : 'withdrawal',
        notes: notes
    });
    
    // Update account balance
    if (savingsData.accounts && savingsData.accounts[accountId]) {
        savingsData.accounts[accountId].balance += amount;
    }
    
    // Save updated data
    localStorage.setItem('savingsData', JSON.stringify(savingsData));
}

// Investment data functions
function loadInvestmentData() {
    const investmentData = JSON.parse(localStorage.getItem('investmentData') || '{}');
    
    // If no investment data exists, initialize with default data
    if (!investmentData.holdings) {
        investmentData.holdings = [
            {
                symbol: 'AAPL',
                name: 'Apple Inc.',
                type: 'stock',
                quantity: 10,
                avgPrice: 150,
                currentPrice: 175.50
            },
            {
                symbol: 'MSFT',
                name: 'Microsoft',
                type: 'stock',
                quantity: 8,
                avgPrice: 220,
                currentPrice: 245.75
            },
            {
                symbol: 'AMZN',
                name: 'Amazon',
                type: 'stock',
                quantity: 5,
                avgPrice: 320,
                currentPrice: 345.20
            },
            {
                symbol: 'GOOGL',
                name: 'Alphabet',
                type: 'stock',
                quantity: 6,
                avgPrice: 135,
                currentPrice: 142.30
            },
            {
                symbol: 'TSLA',
                name: 'Tesla',
                type: 'stock',
                quantity: 7,
                avgPrice: 280,
                currentPrice: 265.40
            }
        ];
        
        investmentData.transactions = [
            {
                symbol: 'AAPL',
                quantity: 5,
                price: 145,
                date: '2025-06-15',
                type: 'buy',
                notes: 'Initial purchase'
            },
            {
                symbol: 'AAPL',
                quantity: 5,
                price: 155,
                date: '2025-07-20',
                type: 'buy',
                notes: 'Dollar cost averaging'
            },
            {
                symbol: 'MSFT',
                quantity: 8,
                price: 220,
                date: '2025-06-10',
                type: 'buy',
                notes: 'Long-term hold'
            }
        ];
        
        localStorage.setItem('investmentData', JSON.stringify(investmentData));
    }
    
    // Update UI with investment data
    updateInvestmentsUI();
}

function updateInvestmentsUI() {
    const investmentData = JSON.parse(localStorage.getItem('investmentData') || '{}');
    
    // Update total investments amount
    const totalInvestments = calculateTotalInvestments(investmentData);
    const investmentsAmountElements = document.querySelectorAll('.investments .amount');
    investmentsAmountElements.forEach(element => {
        element.textContent = formatCurrency(totalInvestments);
    });
    
    // Update holdings table
    const holdingsTable = document.querySelector('.holdings-table tbody');
    if (holdingsTable && investmentData.holdings) {
        holdingsTable.innerHTML = '';
        
        investmentData.holdings.forEach(holding => {
            const value = holding.quantity * holding.currentPrice;
            const returnPct = ((holding.currentPrice - holding.avgPrice) / holding.avgPrice) * 100;
            const returnClass = returnPct >= 0 ? 'positive' : 'negative';
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${holding.symbol} (${holding.name})</td>
                <td>${holding.quantity}</td>
                <td>${formatCurrency(holding.avgPrice)}</td>
                <td>${formatCurrency(holding.currentPrice)}</td>
                <td>${formatCurrency(value)}</td>
                <td class="${returnClass}">${returnPct >= 0 ? '+' : ''}${returnPct.toFixed(1)}%</td>
            `;
            
            holdingsTable.appendChild(row);
        });
    }
}

function calculateTotalInvestments(investmentData) {
    let total = 0;
    
    if (investmentData.holdings) {
        investmentData.holdings.forEach(holding => {
            total += holding.quantity * holding.currentPrice;
        });
    }
    
    return total;
}

function addInvestmentTransaction(type, symbol, quantity, price, date, notes) {
    const investmentData = JSON.parse(localStorage.getItem('investmentData') || '{}');
    
    // Initialize if needed
    if (!investmentData.holdings) investmentData.holdings = [];
    if (!investmentData.transactions) investmentData.transactions = [];
    
    // Add transaction
    investmentData.transactions.push({
        symbol: symbol,
        quantity: quantity,
        price: price,
        date: date,
        type: type,
        notes: notes
    });
    
    // Update or add holding
    let holdingExists = false;
    
    for (let i = 0; i < investmentData.holdings.length; i++) {
        if (investmentData.holdings[i].symbol === symbol) {
            // Update existing holding
            const currentHolding = investmentData.holdings[i];
            const currentValue = currentHolding.quantity * currentHolding.avgPrice;
            const newValue = quantity * price;
            const newQuantity = currentHolding.quantity + quantity;
            
            // Calculate new average price
            currentHolding.avgPrice = (currentValue + newValue) / newQuantity;
            currentHolding.quantity = newQuantity;
            currentHolding.currentPrice = price; // In a real app, this would come from an API
            
            holdingExists = true;
            break;
        }
    }
    
    if (!holdingExists) {
        // Add new holding
        investmentData.holdings.push({
            symbol: symbol,
            name: symbol, // In a real app, this would come from an API
            type: type,
            quantity: quantity,
            avgPrice: price,
            currentPrice: price // In a real app, this would come from an API
        });
    }
    
    // Save updated data
    localStorage.setItem('investmentData', JSON.stringify(investmentData));
}

// Goals data functions
function loadGoalsData() {
    const goalsData = JSON.parse(localStorage.getItem('goalsData') || '{}');
    
    // If no goals data exists, initialize with default data
    if (!goalsData.goals) {
        goalsData.goals = [
            {
                name: 'Home Down Payment',
                targetAmount: 50000,
                currentAmount: 22500,
                targetDate: '2026-12-31',
                monthlyContribution: 800,
                notes: 'For a 3-bedroom house'
            },
            {
                name: 'Vacation Fund',
                targetAmount: 5000,
                currentAmount: 3750,
                targetDate: '2026-06-30',
                monthlyContribution: 250,
                notes: 'European tour'
            },
            {
                name: 'Retirement Fund',
                targetAmount: 1000000,
                currentAmount: 150000,
                targetDate: '2050-01-01',
                monthlyContribution: 1200,
                notes: 'Long-term retirement savings'
            }
        ];
        
        localStorage.setItem('goalsData', JSON.stringify(goalsData));
    }
    
    // Update UI with goals data
    updateGoalsUI();
}

function updateGoalsUI() {
    const goalsData = JSON.parse(localStorage.getItem('goalsData') || '{}');
    
    // Update goals list
    const goalsList = document.querySelector('.goals-list');
    if (goalsList && goalsData.goals) {
        goalsList.innerHTML = '';
        
        goalsData.goals.forEach(goal => {
            const progress = (goal.currentAmount / goal.targetAmount) * 100;
            const progressPercent = Math.round(progress);
            
            const targetDate = new Date(goal.targetDate);
            const formattedDate = targetDate.toLocaleDateString('en-US', { year: 'numeric', month: 'long' });
            
            const goalCard = document.createElement('div');
            goalCard.className = 'goal-card';
            goalCard.innerHTML = `
                <div class="goal-info">
                    <h3>${goal.name}</h3>
                    <div class="goal-progress">
                        <div class="progress-container">
                            <div class="progress-bar" style="width: ${progressPercent}%;">${progressPercent}%</div>
                        </div>
                        <p>${formatCurrency(goal.currentAmount)} / ${formatCurrency(goal.targetAmount)}</p>
                    </div>
                    <p class="goal-date">Target Date: ${formattedDate}</p>
                    <p class="goal-monthly">Monthly Contribution: ${formatCurrency(goal.monthlyContribution)}</p>
                </div>
                <div class="goal-actions">
                    <button class="action-btn edit-btn" data-goal="${goal.name}">Edit</button>
                    <button class="action-btn contribute-btn" data-goal="${goal.name}">Contribute</button>
                </div>
            `;
            
            goalsList.appendChild(goalCard);
        });
        
        // Add event listeners to goal buttons
        const editButtons = document.querySelectorAll('.edit-btn');
        editButtons.forEach(button => {
            button.addEventListener('click', function() {
                const goalName = this.getAttribute('data-goal');
                // In a real app, you would populate a form with the goal data
                alert(`Edit functionality for ${goalName} would be implemented in a real app.`);
            });
        });
        
        const contributeButtons = document.querySelectorAll('.contribute-btn');
        contributeButtons.forEach(button => {
            button.addEventListener('click', function() {
                const goalName = this.getAttribute('data-goal');
                // In a real app, you would show a contribution form
                alert(`Contribution functionality for ${goalName} would be implemented in a real app.`);
            });
        });
    }
}

function addFinancialGoal(name, targetAmount, targetDate, initialAmount, monthlyContribution, notes) {
    const goalsData = JSON.parse(localStorage.getItem('goalsData') || '{}');
    
    // Initialize if needed
    if (!goalsData.goals) goalsData.goals = [];
    
    // Add new goal
    goalsData.goals.push({
        name: name,
        targetAmount: targetAmount,
        currentAmount: initialAmount,
        targetDate: targetDate,
        monthlyContribution: monthlyContribution,
        notes: notes
    });
    
    // Save updated data
    localStorage.setItem('goalsData', JSON.stringify(goalsData));
}

// Utility functions
function formatCurrency(amount) {
    return '$' + amount.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
}